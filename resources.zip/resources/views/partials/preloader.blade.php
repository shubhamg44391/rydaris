<!-- Fullscreen Video Preloader — hidden by default, shows only on first nav click -->
<div id="sitePreloader" class="site-preloader" style="display:none; opacity:0;">
    <video id="preloaderVideo" src="{{ asset('assets/loader/loader.mp4') }}" muted playsinline preload="auto" style="position:absolute; top:0; left:0; width:100%; height:100%; object-fit:cover; object-position:center; display:block;"></video>
</div>

<script>
  (function() {
    var STORAGE_KEY = 'rydaris_loader_shown';

    window.__rydarisShowLoader = function(navigateTo) {
      // Mark as shown for this session
      try { sessionStorage.setItem(STORAGE_KEY, '1'); } catch(e) {}

      var loader = document.getElementById('sitePreloader');
      var video  = document.getElementById('preloaderVideo');

      if (!loader || !video) {
        window.location.href = navigateTo;
        return;
      }

      // Show loader fullscreen
      loader.style.cssText = 'display:block !important; opacity:0; position:fixed; top:0; left:0; right:0; bottom:0; z-index:999999; background:#050711; overflow:hidden; transition:opacity 0.3s ease;';

      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          loader.style.opacity = '1';
        });
      });

      // Play video
      video.currentTime = 0;
      video.muted = true;
      video.play().catch(function() {});

      var navigated = false;
      function doNavigate() {
        if (navigated) return;
        navigated = true;
        window.location.href = navigateTo;
      }

      video.addEventListener('ended', doNavigate);
      setTimeout(doNavigate, 10000);
    };

    // Intercept ALL internal anchor clicks — first time per session only
    document.addEventListener('DOMContentLoaded', function() {
      document.body.addEventListener('click', function(e) {

        // Already shown this session? Skip
        var alreadyShown = false;
        try { alreadyShown = !!sessionStorage.getItem(STORAGE_KEY); } catch(ex) {}
        if (alreadyShown) return;

        // Find the clicked anchor
        var target = e.target.closest('a');
        if (!target) return;

        var href = target.getAttribute('href');
        if (!href || href.trim() === '') return;

        // Skip hash, mailto, tel, javascript, new-tab
        if (
          href === '#' ||
          href.startsWith('#') ||
          href.startsWith('mailto:') ||
          href.startsWith('tel:') ||
          href.startsWith('javascript:') ||
          target.getAttribute('target') === '_blank'
        ) return;

        // *** KEY FIX: Check if it's the SAME hostname (Laravel route() generates full URLs) ***
        try {
          var linkUrl = new URL(href, window.location.href);
          // If different hostname = truly external, skip
          if (linkUrl.hostname !== window.location.hostname) return;
          // Same hostname = internal link, use full URL
          href = linkUrl.href;
        } catch(err) {
          return; // invalid URL
        }

        // Valid internal link — intercept and show loader!
        e.preventDefault();
        e.stopPropagation();

        window.__rydarisShowLoader(href);
      }, true);
    });
  })();
</script>
